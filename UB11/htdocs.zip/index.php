<?php include('auth.php'); ?>
<html>
<head>
<title>Gallery Champaign
</title>
<style type="text/css">
	table.gsc-search-box {visibility:hidden;}
</style>
</head>


<body style="font-family: Arial;border: 0 none;">
<div align="center" width="400" height="400">
<?php

	if(isset($_SESSION)&&$_SESSION['loggedin']==true){
		echo '<a href="logout.php">logout</a>';
		echo '<br><br><br><br>
			<form action="upload.php" method="post" enctype="multipart/form-data">
			<input type="file" name="picture"><br>
			Tags: <input type="text" name="tags"><br>
			<input type="submit" value="Hochladen">
			</form>';}
	else
		echo '<a href="login.php">login to upload pictures</a>';

	echo '<br><br><br><br><br>';


	$path = "/opt/lampp/htdocs/userdata/images";
	$relative = "userdata/images/";
	$txt="userdata/tags.txt";
	$pid = "";

	#read parameter if specified
	if(!empty($_GET)) {
		$pid = htmlspecialchars($_GET["id"]);
	}

	#scan files
	$files = scandir($path);
	$nFiles = count($files);

	#set usefull id
	if($pid == "" or $pid < 2 or $pid >= $nFiles)
	{
		$pid = 2;
	}

	#if a file exists
	if($nFiles > 2) { 
		$file = $files[$pid];
?>
<table border="0">  <colgroup width="140" span="3"></colgroup><tr> <th> 
<?php
		#insert previous arrow
		if($pid > 2) {
			$temp = $pid-1;
			echo "<a href=\"index.php?id=$temp\"><img height='50' src=\"backarrow.png\"/></a>";
		}
?>
</th><th>
<?php
		#insert back arrow
		if($pid < $nFiles -1) {
			$temp = $pid+1;
			echo "<a href=\"index.php?id=$temp\"><img height='50' src=\"forwardarrow.png\"/></a>";
		}
?>
</th></tr></table>
<?php

		$datei = "$txt"; 
		$tags="";
		$array = file($datei);
		for($i=0;$i<count($array);$i++)
			if(strpos($array[$i],$file)===0)
				$tags = $array[$i];

		$tags = substr($tags,strlen($file));
		echo "Tags: ";
		echo $tags;
		#display picture
		echo "<br><h1>$file</h1><br> <img src=\"$relative$file\"/> <br><br>";

		# RESTfull Google API Search
		$apikey = "ABQIAAAA3gEIruBrbLZ7QVwNKWB-LBQVNXOUXbq_x6dWScl8H471LBxP5BRIBNg_1LUH4j9ob8zBAPA2KYrVsg";

		$search = str_replace(" ","%20",$tags);

		//q = query; key=apikey; rsz=resultsize; 
		$url = "https://ajax.googleapis.com/ajax/services/search/images?v=1.0&q=$search&key=$apikey&srz=5&as_rights=cc_publicdomain";

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_REFERER, "alp5.fu-berlin.de");
		$body = curl_exec($ch);
		curl_close($ch);	
		$json = json_decode($body);

		for($i=0;$i<5;$i++){
			if($i==count($json->responseData->results))
				break;
			echo "<a  href='";
			echo $json->responseData->results[$i]->originalContextUrl;
			echo "'>";
			echo $json->responseData->results[$i]->title;
			echo "<br><img src='";
			echo $json->responseData->results[$i]->url;
			echo "' size=";
			echo $json->responseData->results[$i]->tbHeight;
			echo "; width=";
			echo $json->responseData->results[$i]->tbWidth;
			echo ";>";	
			echo "</a><br>";
		}



	} else {
		#error
		echo "No files in Gallery";
	}






?>
</div>
</body>
</html>
