<?php include('auth_hard.php'); ?>
<html>
<head>
<title>Gallery Champaign
</title>
</head>
<body bgcolor=#ffcc77>

<?php
	$type = GetImageSize($_FILES['picture']['tmp_name']);
	if($type[2] != 0)
   	{
		move_uploaded_file($_FILES['picture']['tmp_name'], "userdata/images/".$_FILES['picture']['name']);	
		$handler = fOpen("userdata/tags.txt" , "a+");					
		fWrite($handler , $_FILES['picture']['name']);
		fWrite($handler, " ");
		fWrite($handler, $_POST["tags"]);
		fWrite($handler, "\n");
		fClose($handler);	
      			
		echo "Picture ".$_FILES['picture']['name']." received & tags saved";
	}
	else
	{
		echo "Error: File is not a picture";
	}
?>

</body>
</html>
